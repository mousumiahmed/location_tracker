"""
main.py
Entry point to run the desktop application.
"""

from ui.main_window import run_app

if __name__ == "__main__":
    run_app()
