EmergencyLocationTracker/
│
├── 📄 main.py
│   → Entry point; starts the GUI
│
├── 📁 core/
│   ├── __init__.py
│   ├── location_service.py       # Handles GPS / IP geolocation logic
│   ├── api_handler.py            # Makes authorized requests to legal/emergency APIs
│   ├── auth_manager.py           # Secure login or token validation
│   └── data_store.py             # Stores logs of consent, location, timestamps
│
├── 📁 ui/
│   ├── __init__.py
│   ├── main_window.py            # Tkinter GUI main window
│   ├── emergency_form.py         # Dialog to report emergency / missing person
│   ├── map_view.py               # Optional: embedded map view using folium or leaflet
│   └── style.py                  # Colors, font, layout config
│
├── 📁 config/
│   ├── settings.yaml             # App configuration (API keys, endpoints)
│   └── logging.conf              # Logging format and file rotation
│
├── 📁 logs/
│   ├── app.log                   # General application logs
│   └── emergency_requests.log    # Legal/emergency API request logs
│
├── 📁 data/
│   ├── consent_records.db        # SQLite DB for consent & user activity
│   └── temp_location_cache.json  # Cached location data (with user approval)
│
├── 📁 assets/
│   ├── icons/
│   │   └── emergency_icon.png
│   └── ui/
│       └── background.jpg
│
├── 📁 docs/
│   ├── README.md                 # Project overview
│   ├── LEGAL_COMPLIANCE.md       # Notes on lawful data handling
│   ├── API_USAGE_POLICY.md       # Policy for law enforcement API access
│   └── PRIVACY_POLICY.md         # Consent and data use statement
│
├── 📄 requirements.txt            # Required Python dependencies
├── 📄 LICENSE                     # License file (MIT, Apache, etc.)
└── 📄 setup.py                    # For packaging (if you want an installer)
