"""
main_window.py
Tkinter-based GUI for the desktop emergency app.
Buttons:
- Register Consent
- Start Sharing (create incident + start periodic location capture)
- Stop Sharing (stop and finalize incident)
- Export Report (CSV)
- Send Report to Server
"""

import tkinter as tk
from tkinter import messagebox, filedialog
import threading
import uuid
import time
from datetime import datetime
from core import location_service, data_store, api_handler

POLL_INTERVAL_MS = 10_000  # 10 seconds between location captures (tweak for production)

class EmergencyApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Emergency Location Tracker (Consent Required)")
        self.user_id_var = tk.StringVar(value="user123")
        self.server_url_var = tk.StringVar()
        self.auth_token = None  # if server returns one on consent registration

        # UI layout
        tk.Label(root, text="User ID:").grid(row=0, column=0, sticky="w")
        tk.Entry(root, textvariable=self.user_id_var, width=40).grid(row=0, column=1, columnspan=3, sticky="w")

        self.consent_text = tk.Text(root, height=5, width=60)
        self.consent_text.insert("1.0", "I consent to share my location with authorized emergency contacts and authorities while an incident is active. I understand data retention is limited and I can stop sharing at any time.")
        self.consent_text.grid(row=1, column=0, columnspan=4, pady=8)

        self.register_btn = tk.Button(root, text="Register Consent", command=self.register_consent)
        self.register_btn.grid(row=2, column=0)

        self.start_btn = tk.Button(root, text="Start Sharing (Panic)", command=self.start_sharing, state=tk.DISABLED)
        self.start_btn.grid(row=2, column=1)

        self.stop_btn = tk.Button(root, text="Stop Sharing", command=self.stop_sharing, state=tk.DISABLED)
        self.stop_btn.grid(row=2, column=2)

        self.export_btn = tk.Button(root, text="Export Report (CSV)", command=self.export_report)
        self.export_btn.grid(row=2, column=3)

        tk.Label(root, text="Status:").grid(row=3, column=0, sticky="w", pady=(10,0))
        self.status_label = tk.Label(root, text="Idle", wraplength=500, justify="left")
        self.status_label.grid(row=4, column=0, columnspan=4, sticky="w")

        tk.Label(root, text="Local Incident Log:").grid(row=5, column=0, sticky="w", pady=(10,0))
        self.log_text = tk.Text(root, height=10, width=70)
        self.log_text.grid(row=6, column=0, columnspan=4, pady=(0,10))
        self.incident_id = None
        self._polling = False

    def log(self, msg):
        ts = datetime.utcnow().isoformat() + "Z"
        self.log_text.insert("1.0", f"[{ts}] {msg}\n")
        self.log_text.see("1.0")
        self.status_label.config(text=msg)

    def register_consent(self):
        user_id = self.user_id_var.get().strip()
        if not user_id:
            messagebox.showwarning("Missing user id", "Please enter a user id before registering consent.")
            return
        consent_text = self.consent_text.get("1.0", "end").strip()
        # local store
        data_store.record_consent(user_id, consent_text)
        self.log(f"Consent recorded locally for user {user_id}")
        # try registering with server too (optional)
        try:
            code, text = api_handler.send_consent(user_id, consent_text)
            if code is None:
                self.log(f"Consent remote failed: {text}")
            elif int(code) >= 200 and int(code) < 300:
                self.log("Consent recorded on server (if server available).")
            else:
                self.log(f"Server consent responded: {code} - {text}")
        except Exception as e:
            self.log("Consent remote registration error: " + str(e))
        self.start_btn.config(state=tk.NORMAL)

    def start_sharing(self):
        if self._polling:
            return
        user_id = self.user_id_var.get().strip()
        if not user_id:
            messagebox.showwarning("Missing user id", "Please enter a user id before starting sharing.")
            return
        self.incident_id = f"inc-{uuid.uuid4().hex[:12]}"
        data_store.start_incident(self.incident_id, user_id)
        self.log(f"Incident {self.incident_id} started for user {user_id}")
        # try notify server
        code, text = api_handler.send_incident_start(self.incident_id, user_id, token=self.auth_token)
        if code and 200 <= int(code) < 300:
            self.log("Server incident start acknowledged.")
        else:
            self.log(f"Server incident start response: {code} / {text}")

        self._polling = True
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        # start periodic location sampling using tkinter after
        self._schedule_poll()

    def _schedule_poll(self):
        if not self._polling:
            return
        # run sampling in thread to avoid blocking the UI
        threading.Thread(target=self._capture_and_send).start()
        # schedule next poll
        self.root.after(POLL_INTERVAL_MS, self._schedule_poll)

    def _capture_and_send(self):
        # get best location
        loc = location_service.get_best_location()
        if not loc:
            self.log("Unable to obtain location (GPS and IP lookup failed).")
            return
        self.log(f"Captured location method={loc.get('method')} lat={loc['lat']:.6f} lon={loc['lon']:.6f} acc={loc.get('accuracy')}")
        # store locally
        data_store.add_location(self.incident_id, loc['lat'], loc['lon'], loc.get('accuracy'), loc['timestamp'])
        # attempt to forward to server
        payload = {
            "incident_id": self.incident_id,
            "user_id": self.user_id_var.get().strip(),
            "lat": loc['lat'],
            "lon": loc['lon'],
            "accuracy": loc.get('accuracy'),
            "timestamp": loc['timestamp']
        }
        code, text = api_handler.send_incident_update(payload, token=self.auth_token)
        if code is None:
            self.log(f"Failed to send update to server: {text}")
        elif 200 <= int(code) < 300:
            self.log("Update sent to server successfully.")
        else:
            self.log(f"Server responded to update: {code} / {text}")

    def stop_sharing(self):
        if not self._polling:
            return
        self._polling = False
        data_store.stop_incident(self.incident_id)
        code, text = api_handler.send_incident_stop(self.incident_id, token=self.auth_token)
        if code and 200 <= int(code) < 300:
            self.log("Incident stopped on server.")
        else:
            self.log(f"Server stop response: {code} / {text}")
        self.log(f"Incident {self.incident_id} stopped and stored locally.")
        messagebox.showinfo("Stopped", f"Sharing stopped for incident {self.incident_id}")
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)

    def export_report(self):
        if not self.incident_id:
            messagebox.showwarning("No incident", "No incident to export. Start an incident first.")
            return
        out = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files","*.csv")], title="Save incident report")
        if not out:
            return
        ok = data_store.export_incident_csv(self.incident_id, out)
        if ok:
            messagebox.showinfo("Exported", f"Incident exported to {out}")
            self.log(f"Incident exported to {out}")
        else:
            messagebox.showerror("Export failed", "Could not export incident report.")

def run_app():
    root = tk.Tk()
    app = EmergencyApp(root)
    root.mainloop()

if __name__ == "__main__":
    run_app()
