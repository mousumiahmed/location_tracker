# server/server.py
from flask import Flask, request, jsonify
import sqlite3, os
from datetime import datetime
import json

DB = "server_incidents.db"

def init_db():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('CREATE TABLE IF NOT EXISTS consents (id INTEGER PRIMARY KEY, user_id TEXT, consent_text TEXT, ts TEXT)')
    c.execute('CREATE TABLE IF NOT EXISTS incidents (incident_id TEXT PRIMARY KEY, user_id TEXT, started_at TEXT, stopped_at TEXT)')
    c.execute('CREATE TABLE IF NOT EXISTS locations (id INTEGER PRIMARY KEY AUTOINCREMENT, incident_id TEXT, lat REAL, lon REAL, accuracy REAL, ts TEXT)')
    conn.commit()
    conn.close()

app = Flask(__name__)
init_db()

@app.route("/v1/consent/register", methods=["POST"])
def consent_register():
    data = request.get_json() or {}
    if "user_id" not in data or "consent_text" not in data:
        return jsonify({"error":"bad_payload"}), 400
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('INSERT INTO consents (user_id, consent_text, ts) VALUES (?, ?, ?)', (data["user_id"], data["consent_text"], datetime.utcnow().isoformat()+"Z"))
    conn.commit()
    conn.close()
    # Demo: don't return a token; client continues unauth'd (in prod use JWT)
    return jsonify({"status":"consent_recorded"}), 201

@app.route("/v1/incident/start", methods=["POST"])
def incident_start():
    data = request.get_json() or {}
    if "incident_id" not in data or "user_id" not in data:
        return jsonify({"error":"bad_payload"}), 400
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('INSERT OR REPLACE INTO incidents (incident_id, user_id, started_at) VALUES (?,?,?)',
              (data["incident_id"], data["user_id"], datetime.utcnow().isoformat()+"Z"))
    conn.commit()
    conn.close()
    return jsonify({"status":"incident_started"}), 201

@app.route("/v1/incident/update", methods=["POST"])
def incident_update():
    data = request.get_json() or {}
    required = ["incident_id", "user_id", "lat", "lon", "timestamp"]
    if any(k not in data for k in required):
        return jsonify({"error":"bad_payload"}), 400
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('INSERT INTO locations (incident_id, lat, lon, accuracy, ts) VALUES (?, ?, ?, ?, ?)',
              (data["incident_id"], float(data["lat"]), float(data["lon"]), float(data.get("accuracy") or 0.0), data["timestamp"]))
    conn.commit()
    conn.close()
    return jsonify({"status":"location_saved"}), 201

@app.route("/v1/incident/stop", methods=["POST"])
def incident_stop():
    data = request.get_json() or {}
    if "incident_id" not in data:
        return jsonify({"error":"bad_payload"}), 400
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('UPDATE incidents SET stopped_at=? WHERE incident_id=?', (datetime.utcnow().isoformat()+"Z", data["incident_id"]))
    conn.commit()
    # return gathered report
    c.execute('SELECT lat,lon,accuracy,ts FROM locations WHERE incident_id=? ORDER BY id ASC', (data["incident_id"],))
    rows = c.fetchall()
    conn.close()
    report = [{"lat":r[0],"lon":r[1],"accuracy":r[2],"ts":r[3]} for r in rows]
    return jsonify({"status":"stopped","report":report}), 200

if __name__ == "__main__":
    # In dev: run without TLS. In production: run behind HTTPS server (nginx) or use flask ssl_context.
    app.run(host="0.0.0.0", port=5000, debug=True)
