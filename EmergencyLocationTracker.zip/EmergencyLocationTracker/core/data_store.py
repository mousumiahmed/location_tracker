"""
data_store.py
Simple SQLite-based store for consent, incidents, and locations.
Also provides export functionality for incident reports.
"""

import sqlite3
from pathlib import Path
from datetime import datetime, timedelta
import csv
import json
import os

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "consent_and_incidents.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
      CREATE TABLE IF NOT EXISTS consents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        consent_text TEXT,
        ts TEXT
      )
    ''')
    c.execute('''
      CREATE TABLE IF NOT EXISTS incidents (
        incident_id TEXT PRIMARY KEY,
        user_id TEXT,
        started_at TEXT,
        stopped_at TEXT
      )
    ''')
    c.execute('''
      CREATE TABLE IF NOT EXISTS locations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        incident_id TEXT,
        lat REAL,
        lon REAL,
        accuracy REAL,
        ts TEXT
      )
    ''')
    conn.commit()
    conn.close()

def record_consent(user_id, consent_text):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('INSERT INTO consents (user_id, consent_text, ts) VALUES (?, ?, ?)',
              (user_id, consent_text, datetime.utcnow().isoformat() + "Z"))
    conn.commit()
    conn.close()

def start_incident(incident_id, user_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('INSERT OR REPLACE INTO incidents (incident_id, user_id, started_at) VALUES (?, ?, ?)',
              (incident_id, user_id, datetime.utcnow().isoformat() + "Z"))
    conn.commit()
    conn.close()

def add_location(incident_id, lat, lon, accuracy, ts):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('INSERT INTO locations (incident_id, lat, lon, accuracy, ts) VALUES (?, ?, ?, ?, ?)',
              (incident_id, float(lat), float(lon), float(accuracy) if accuracy is not None else None, ts))
    conn.commit()
    conn.close()

def stop_incident(incident_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('UPDATE incidents SET stopped_at=? WHERE incident_id=?',
              (datetime.utcnow().isoformat() + "Z", incident_id))
    conn.commit()
    conn.close()

def fetch_incident_report(incident_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT incident_id, user_id, started_at, stopped_at FROM incidents WHERE incident_id=?', (incident_id,))
    incident = c.fetchone()
    c.execute('SELECT lat, lon, accuracy, ts FROM locations WHERE incident_id=? ORDER BY id ASC', (incident_id,))
    rows = c.fetchall()
    conn.close()
    if not incident:
        return None
    report = {
        "incident_id": incident[0],
        "user_id": incident[1],
        "started_at": incident[2],
        "stopped_at": incident[3],
        "locations": [{"lat":r[0], "lon":r[1], "accuracy":r[2], "ts":r[3]} for r in rows]
    }
    return report

def export_incident_csv(incident_id, out_path):
    report = fetch_incident_report(incident_id)
    if not report:
        return False
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["incident_id", report["incident_id"]])
        writer.writerow(["user_id", report["user_id"]])
        writer.writerow(["started_at", report["started_at"]])
        writer.writerow(["stopped_at", report["stopped_at"]])
        writer.writerow([])
        writer.writerow(["lat","lon","accuracy","timestamp"])
        for loc in report["locations"]:
            writer.writerow([loc["lat"], loc["lon"], loc["accuracy"], loc["ts"]])
    return True

# initialize DB on import
init_db()
