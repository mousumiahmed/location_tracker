"""
location_service.py
Provides methods to obtain device location.
- get_coarse_location_ip(): uses IP geolocation (coarse, city-level).
- get_gps_location(): optional, tries to read from gpsd if available (requires gpsd client).
Both return a dict: { 'lat': float, 'lon': float, 'accuracy': float or None, 'timestamp': ISO8601 }
"""

import requests
from datetime import datetime
import json

from pathlib import Path
import yaml

# load config
CFG_PATH = Path(__file__).resolve().parents[1] / "config" / "settings.yaml"
with open(CFG_PATH, "r", encoding="utf-8") as f:
    CFG = yaml.safe_load(f)

IP_PROVIDER = CFG.get("location", {}).get("ip_provider", "https://ipinfo.io/json")

def _now_iso():
    return datetime.utcnow().isoformat() + "Z"

def get_coarse_location_ip():
    """
    Use an IP geolocation service (ipinfo.io) to get a coarse lat/lon.
    This is not precise and should only be used for fallback / analytics.
    """
    try:
        resp = requests.get(IP_PROVIDER, timeout=6)
        resp.raise_for_status()
        data = resp.json()
        # ipinfo returns "loc": "lat,lon"
        loc = data.get("loc", "")
        if loc:
            lat_str, lon_str = loc.split(",", 1)
            return {
                "lat": float(lat_str),
                "lon": float(lon_str),
                "accuracy": None,
                "timestamp": _now_iso(),
                "provider": "ipinfo"
            }
        else:
            return None
    except Exception as e:
        return None

def get_gps_location():
    """
    Optional: attempt to read from gpsd (if installed and running).
    This requires that gpsd is installed and accessible (Linux mostly).
    We'll try a minimal approach to avoid extra dependencies:
    If gpsd JSON socket is available, parse. Otherwise return None.
    """
    try:
        import socket, time
        # gpsd's default TCP port is 2947 (but usually requires json module or gps library)
        s = socket.create_connection(("127.0.0.1", 2947), timeout=2)
        # Ask gpsd for JSON TPV updates
        s.sendall(b'?WATCH={"enable":true,"json":true};\n')
        time_start = time.time()
        buff = b""
        while time.time() - time_start < 3:
            part = s.recv(4096)
            if not part:
                break
            buff += part
            if b'TPV' in buff:
                break
        text = buff.decode(errors="ignore")
        # find TPV JSON
        import re
        match = re.search(r'({.*"class"\s*:\s*"TPV".*?})', text, flags=re.S)
        if match:
            tpv = json.loads(match.group(1))
            lat = tpv.get("lat")
            lon = tpv.get("lon")
            eph = tpv.get("eph")  # estimated horizontal position error (meters)
            if lat and lon:
                return {
                    "lat": float(lat),
                    "lon": float(lon),
                    "accuracy": float(eph) if eph else None,
                    "timestamp": _now_iso(),
                    "provider": "gpsd"
                }
        return None
    except Exception:
        return None

def get_best_location():
    """
    Try GPS first (if available), otherwise fallback to IP-based coarse location.
    """
    gps = get_gps_location()
    if gps:
        gps["method"] = "gps"
        return gps
    iploc = get_coarse_location_ip()
    if iploc:
        iploc["method"] = "ip"
        return iploc
    return None
