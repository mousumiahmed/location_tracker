"""
api_handler.py
Minimal code to send incidents / location updates to a configured server endpoint.
Used to forward incidents to a central server (for law enforcement handoff).
"""

import requests
from pathlib import Path
import yaml
import json

CFG_PATH = Path(__file__).resolve().parents[1] / "config" / "settings.yaml"
with open(CFG_PATH, "r", encoding="utf-8") as f:
    CFG = yaml.safe_load(f)

SERVER_BASE = CFG.get("server", {}).get("url", "http://localhost:5000")

def _post(path, payload, token=None):
    url = SERVER_BASE.rstrip("/") + path
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        resp = requests.post(url, json=payload, headers=headers, timeout=8)
        return resp.status_code, resp.text
    except Exception as e:
        return None, str(e)

def send_consent(user_id, consent_text):
    payload = {"user_id": user_id, "consent_text": consent_text}
    path = CFG["server"].get("consent_register_path", "/v1/consent/register")
    return _post(path, payload)

def send_incident_start(incident_id, user_id, token=None):
    payload = {"incident_id": incident_id, "user_id": user_id, "timestamp": None}
    path = CFG["server"].get("incident_start_path", "/v1/incident/start")
    return _post(path, payload, token=token)

def send_incident_update(payload, token=None):
    path = CFG["server"].get("incident_update_path", "/v1/incident/update")
    return _post(path, payload, token=token)

def send_incident_stop(incident_id, token=None):
    payload = {"incident_id": incident_id}
    path = CFG["server"].get("incident_stop_path", "/v1/incident/stop")
    return _post(path, payload, token=token)
